import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewRatingService } from '../services/rating.service';
import { IRating } from '../interfaces/rating';

@Component({
  selector: 'app-update-rating',
  templateUrl: './update-rating.component.html',
  styleUrls: ['./update-rating.component.css']
})
export class UpdateRatingComponent implements OnInit {

  emailId: string;
  productId: string;
  productName: string;
  reviewRating: number;
  reviewComments: string;
  status: boolean;
  errorMsg: string;

  constructor(private route: ActivatedRoute, private rateservice: ViewRatingService, private router: Router) { }

  ngOnInit() {
    this.emailId = sessionStorage.getItem("userName");
    if (this.emailId == null) {
      this.router.navigate(['/login']);
    }

    this.productName = this.route.snapshot.params['productName'];
    this.productId = this.route.snapshot.params['productId'];
    this.reviewRating = parseInt(this.route.snapshot.params['reviewRating']);
    this.reviewComments = this.route.snapshot.params['reviewComments'];
  }
  InsertReview(reviewrating: number, reviewcomment: string) {
    this.rateservice.InsertRating(this.productId, this.productName, reviewrating, reviewcomment).subscribe(
      response => {
        this.status = response;
        if (this.status) {
          alert("review inserted successfully");
        }
        else
          alert("some error occured in insertion of reviews");
      },
      error => { console.log("error in insert service of rating"); },
      () => { console.log("rating method  insertion successfully taking place"); }
    );

  }

 

}
