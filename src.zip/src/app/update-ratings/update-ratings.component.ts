import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewRatingService } from '../services/rating.service';

@Component({
  selector: 'app-update-ratings',
  templateUrl: './update-ratings.component.html',
  styleUrls: ['./update-ratings.component.css']
})
export class UpdateRatingsComponent implements OnInit {

  emailId: string;
  productId: string;
  productName: string;
  reviewRating: number;
  reviewComments: string;
  status: boolean;
  errorMsg: string;

  constructor(private rateservice: ViewRatingService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.emailId = sessionStorage.getItem('userName');
    if (this.emailId == null)
      this.router.navigate(['/login']);
    this.productId = this.route.snapshot.params['productId'];
    this.productName = this.route.snapshot.params['productName'];
    this.reviewRating = parseInt(this.route.snapshot.params['reviewRating']);
    this.reviewComments = this.route.snapshot.params['reviewComments'];
  }
  UpdateReview(reviewrating:number,reviewcomment: string) {
    this.rateservice.UpdateReviewComments(this.productName, this.emailId, this.productId, reviewrating, reviewcomment).subscribe(
      response => {
        this.status = response;
        if (this.status) {
          alert("review updated successfully");
        }
        else
          alert("some error occured in updation of reviews");
      },
      error => { console.log("error in update service of rating"); },
      () => { console.log("rating method  updation successfully taking place"); }
    );

  }

}
