import { Component, OnInit } from '@angular/core';
import { ICartProduct } from '../interfaces/cartproduct';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrls: ['./view-cart.component.css']
})
export class ViewCartComponent {

  errorMsg: string;
  emailId: string;
  Products: ICartProduct[];
  showError: boolean = false;
  status: boolean = false;
  imageSrc: string;


  constructor(private _userService: UserService, private router: Router) { }


  ngOnInit() {
    this.emailId = sessionStorage.getItem('userName');
    if (this.emailId == null) {
      this.router.navigate(['/login']);
    }
    this._userService.getCartProducts(this.emailId)
      .subscribe(
        resCartProductData => {
          this.Products = resCartProductData;
          if (this.Products.length == 0) {
            this.showError = true;
            this.errorMsg = "Your cart is empty.";
          }
        },
        resCartProductError => {
          this.Products = null;
          this.errorMsg = resCartProductError;
          console.log(this.errorMsg);
          if (this.Products.length == 0) {
            this.showError = true;
            this.errorMsg = "No records found.";
          }
        },
        () => console.log("GetCartProducts method executed successfully")
    );
    
    this.imageSrc = "../../assets/images/delete-item.jpg";
    //console.log(this.imageSrc);
  }
  updateCart(prod: ICartProduct) {
    this.router.navigate(['/updateCart', prod.ProductId, prod.ProductName, prod.Quantity, prod.QuantityAvailable]);
  }

  removeProductFromCart(prod: ICartProduct) {
    this._userService.deleteCartProduct(prod.ProductId, this.emailId).subscribe(
      response => {
        this.status = response;
        if (this.status) {
          alert("product deleted successfully");
          this.ngOnInit();
        }
        else
          alert("product could not be deleted...please try once again");
      },
      error => {
        this.errorMsg = error;
        alert("something went wrong");
      },

      () => { console.log("remove product from cart method excuted") }
     );
  
  }

}
