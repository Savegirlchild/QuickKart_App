import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commonlayout',
  templateUrl: './commonlayout.component.html',
  styleUrls: ['./commonlayout.component.css']
})
export class CommonlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
