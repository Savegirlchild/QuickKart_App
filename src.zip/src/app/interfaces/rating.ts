export class IRating {
  EmailId: string;
  ProductId: string;
  ProductName: string;
  ReviewRating: number;
  ReviewComments: string;
}
