export interface IPurchaseDetails {
  PurchaseId: number;
  ProductName: string;
  EmailId: string;
  ProductId: string;
  QuantityPurchased: number;
  PurchaseDate: Date;
}
