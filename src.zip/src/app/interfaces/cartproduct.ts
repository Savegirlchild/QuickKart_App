export class ICartProduct {
  ProductId: string;
  ProductName: string;
  Price: number;
  Quantity: number;
  QuantityAvailable: number;
}
