import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ViewProductsComponent } from './view-products/view-products.component';
import { PurchasedetailsComponent } from './purchasedetails/purchasedetails.component';
import { UpdateCartComponent } from './update-cart/update-cart.component';
import { ViewCartComponent } from './view-cart/view-cart.component';
import { ViewRatingComponent } from './view-rating/view-rating.component';
import { UpdateRatingComponent } from './update-rating/update-rating.component';
import { UpdateRatingsComponent } from './update-ratings/update-ratings.component';
import { UserregisterComponent } from './userregister/userregister.component';

 export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
   { path: 'login', component: LoginComponent },
   { path: 'register', component: UserregisterComponent },
   { path: 'viewProducts', component: ViewProductsComponent },
   { path: 'purchasedetails', component: PurchasedetailsComponent },
   { path: 'viewCart', component: ViewCartComponent },
   { path: 'viewRating', component: ViewRatingComponent },
   { path: 'updateCart/:productId/:productName/:quantity/:quantityAvailable', component: UpdateCartComponent },
   { path: 'updateRating/:productId/:productName', component: UpdateRatingComponent },
   { path: 'updateRatings/:productId/:productName', component: UpdateRatingsComponent },
   

];

//export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
