import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  //form group-->ngForm it identifies the form template //mapped to a form group
  //form control-->ngModel

  userRole: string;

  status: string;
  errorMsg: string;
  msg: string;
  showDiv: boolean = false;

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
    
  }
  onsubmit(form: NgForm) {
    // console.log(form.value.email);
    //console.log(form.controls['email']);
    //console.log(form.value.password);
    //console.log(form.controls['password']);
    

    this.userService.validateCredentials(form.value.email, form.value.password).subscribe(
      //response => {
      //  if (response != "Invalid Credentials"){
      //    console.log("login successfull");
      //    this.userRole = response;
      //    console.log(this.userRole);

      

      //  }
      //else
      //    console.log("Invalid Credentials");
      //},
      //error => {
      //  console.log("error occured in login");
      //},
      //() => { console.log("login completed"); }


      responseLoginStatus => {
        this.status = responseLoginStatus;
        this.showDiv = true;
        if (this.status.toLowerCase() != 'invalid credentials') {
          sessionStorage.setItem('userName', form.value.email);
          sessionStorage.setItem('userRole', this.status);
          this.router.navigate(['/home']);
        }
        else {
          this.msg = this.status + ". Try again with valid credentials.";
        }
      },
      responseLoginError => {
        this.errorMsg = responseLoginError;
      },
      () => console.log("SubmitLoginForm method executed successfully")
    );
  }

    
  }




