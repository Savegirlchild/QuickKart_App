import { Component, OnInit } from '@angular/core';
import { IPurchaseDetails } from '../interfaces/purchase';
import { PurchaseService } from '../services/purchase.service';
import { IRating } from '../interfaces/rating';
import { Router } from '@angular/router';


@Component({
  selector: 'app-purchasedetails',
  templateUrl: './purchasedetails.component.html',
  styleUrls: ['./purchasedetails.component.css']
})
export class PurchasedetailsComponent implements OnInit {

  purchasedetails: IPurchaseDetails[];
  customerlayout: boolean = false;
  commonlayout: boolean = false;
  userRole: string;
  userName: string;


  constructor(private purchaseService: PurchaseService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    this.userName = sessionStorage.getItem('userName');
    if (this.userRole == 'Customer')
      this.customerlayout = true;
    else
      this.commonlayout = true;
  }

  ngOnInit() {
   
    this.purchaseService.getpurchasedetails(this.userName).subscribe(
      response => this.purchasedetails = response,
      error => {
        console.log("some error occured in purchase details class");
      },
      () => { console.log("purchase details successfully loaded");}
    );
  }

  insertreview(purchase: IPurchaseDetails) {
    this.router.navigate(['/updateRating', purchase.ProductId, purchase.ProductName]);
  }

}
