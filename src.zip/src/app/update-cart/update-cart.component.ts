import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-update-cart',
  templateUrl: './update-cart.component.html',
  styleUrls: ['./update-cart.component.css']
})
export class UpdateCartComponent implements OnInit {

  productId: string;
  productName: string;
  price: number;
  quantity: number;
  emailId: string;
  quantityAvailable: number;
  status: boolean;
  errorMsg: string;

  constructor(private route: ActivatedRoute, private userservice: UserService, private router: Router) { }

  ngOnInit() {

    this.emailId = sessionStorage.getItem("userName");
    if (this.emailId == null) {
      this.router.navigate(['/login']);

    }
    this.productId = this.route.snapshot.params['productId'];
    this.productName = this.route.snapshot.params['productName'];
    this.price = parseInt(this.route.snapshot.params['price']);
    this.quantity = parseInt(this.route.snapshot.params['quantity']);
    this.quantityAvailable = parseInt(this.route.snapshot.params['quantityAvailable']);
  }

  updateCart(qty: number) {
    this.userservice.updateCartProduct(this.emailId, this.productId, qty).subscribe(
      responseUpdateCartStatus => {
        this.status = responseUpdateCartStatus;
        if (this.status) {
          alert("Product quantity updated successfully.");
        }
        else {
          alert("Some error occured, please try after some time.");
        }
      },
      responseUpdateCartError => {
        this.errorMsg = responseUpdateCartError;
        console.log(this.errorMsg);
        alert("Some error occured, please try after some time.");
      },
      () => console.log("UpdateCart method executed successfully.")
    );
  }

}
