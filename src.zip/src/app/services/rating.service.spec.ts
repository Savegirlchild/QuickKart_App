import { TestBed, inject } from '@angular/core/testing';

import { ViewRatingService } from './view-rating.service';

describe('ViewRatingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewRatingService]
    });
  });

  it('should be created', inject([ViewRatingService], (service: ViewRatingService) => {
    expect(service).toBeTruthy();
  }));
});
