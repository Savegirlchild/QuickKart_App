import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { IRating } from '../interfaces/rating';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ViewRatingService {

  rating: IRating[];
  emailid: string;

  constructor(private http: HttpClient) {
    this.emailid = sessionStorage.getItem('userName');
  }

  DisplayAllReviewDetailsByEmailId(emailId: string): Observable<IRating[]> {
    let params = '?emailId='+emailId;
    let rates = this.http.get<IRating[]>('http://localhost:11990/api/rating/DisplayAllReviewDetailsByEmailId/' + params).pipe(catchError(this.errorHandler))
    return rates;
  }

  InsertRating(productid:string,productname:string,reviewrating:number,comment:string): Observable<boolean> {
    var rate: IRating;
    rate = { EmailId: this.emailid, ProductName: productname, ProductId: productid, ReviewRating: reviewrating, ReviewComments: comment };
    return this.http.post<boolean>('http://localhost:11990/api/rating/InsertRating', rate).pipe(catchError(this.errorHandler));
  }

  UpdateReviewComments(productname:string,emailId: string, productid: string, reviewrating: number, reviewcomments: string): Observable<boolean> {
    var rate: IRating;
    rate = { ProductName: productname, EmailId: emailId, ProductId: productid, ReviewRating: reviewrating, ReviewComments: reviewcomments };
    return this.http.put<boolean>('http://localhost:11990/api/rating/UpdateReviewComments', rate).pipe(catchError(this.errorHandler));
  }

  DeleteRating(productname: string, emailId: string, productid: string, reviewrating: number, reviewcomments: string): Observable<boolean> {
    var rate: IRating;
    rate = { ProductName: productname, EmailId: emailId, ProductId: productid, ReviewRating: reviewrating, ReviewComments: reviewcomments };
    let httpoption = { headers:new HttpHeaders({ 'Content-Type': 'application/json' }), body: rate };
    return this.http.delete<boolean>('http://localhost:11990/api/rating/DeleteRating', httpoption);
  }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error.message);
  }

}
