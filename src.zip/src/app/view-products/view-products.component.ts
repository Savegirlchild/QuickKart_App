import { Component, OnInit } from '@angular/core';
import { IProduct } from '../interfaces/product';
import { ICategory } from '../interfaces/category';
import { ProductService } from '../services/product.service';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { ICart } from '../interfaces/cart';


// every component is a directive
@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {
  name: string = "Nandita";
  products: IProduct[];
  categories: ICategory[];
  filteredProducts: IProduct[];
  showMsgDiv: boolean = false;
  imageSrc: string;
  searchByProductName: string;
  searchByCategoryId: string = "0";
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  userName: string;
  errMsg: string;


  //productservice: ProductService;

  //1.interpolation

  //ngIf i can add remove elements //it is like if condition
  //isValid: boolean = true;

  //ngFor just like for loop
  //products: string[] = ["coffee", "tea", "sugar", "rice"];

  //2.property binding

  //imgpath: string = '../../assets/images/add-item.jpg';

  constructor(private productservice: ProductService, private userService: UserService, private router: Router) { //dependency injection we do in constructor

    //this.productservice = new ProductService();

    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer") {
      this.customerLayout = true;
    }
    else {
      this.commonLayout = true;
    }
  }

  // we will mostly use ngOnInit() to construct an logical things
  // it will construct when all dependencies will load
  ngOnInit() {

    this.productservice.getProducts().subscribe(
      response => {
        this.products = response;
        this.filteredProducts = response;
        this.showMsgDiv = false;
      },
      error => {
        console.log("some error occured in product class");
      },
      () => { console.log("products fetched successfully"); }// when all the above response get executed properly then this part() will get exceuted

    );

    this.productservice.getCategory().subscribe(
      response =>
        this.categories = response,
      error => {
        console.log("some error occured in category class");
      },
      () => { console.log("categories fetched accordingly to products"); }
    );


    //this.products = this.productservice.getProducts();
    //this.categories = this.productservice.getCategories();



    //  this.products = [
    //    { "ProductId": "P101", "ProductName": "Lamborghini Gallardo Spyder", "CategoryId": 1, "Price": 18000000, "QuantityAvailable": 10 },
    //    { "ProductId": "P102", "ProductName": "Ben Sherman Mens Necktie Silk Tie", "CategoryId": 2, "Price": 1847, "QuantityAvailable": 20 },
    //    { "ProductId": "P103", "ProductName": "BMW Z4", "CategoryId": 1, "Price": 6890000, "QuantityAvailable": 10 },
    //    { "ProductId": "P104", "ProductName": "Samsung Galaxy S4", "CategoryId": 3, "Price": 38800, "QuantityAvailable": 100 }
    //  ]
    //  this.categories = [
    //    { "CategoryId": 1, "CategoryName": "Motors" },
    //    { "CategoryId": 2, "CategoryName": "Fashion" },
    //    { "CategoryId": 3, "CategoryName": "Electronics" }
    //  ]
    if (this.products == null) {
      this.showMsgDiv = true;
    }
    this.filteredProducts = this.products;
    this.imageSrc = "../../assets/images/add-item.jpg";
  }
  //searchProductByCategory(categoryId: string) {
  //  this.filteredProducts = this.products;
  //  if (categoryId == "0") {
  //    this.filteredProducts = this.products;
  //  }
  //  else {
  //    this.filteredProducts = this.filteredProducts.filter(prod => prod.CategoryId.toString() == categoryId);
  //  }
  //}

  searchProduct(productName: string) {
    if (this.searchByCategoryId == "0") {
      this.filteredProducts = this.products;
    }
    else {
      this.filteredProducts = this.products.filter(prod => prod.CategoryId.toString() == this.searchByCategoryId);
    }
    if (productName != null || productName == "") {
      this.searchByProductName = productName;
      this.filteredProducts = this.filteredProducts.filter(prod => prod.ProductName.toLowerCase().indexOf(productName.toLowerCase()) >= 0);
    }
    if (this.filteredProducts.length == 0) {
      this.showMsgDiv = true;
    }
    else {
      this.showMsgDiv = false;
    }
  }
  searchProductByCategory(categoryId: string) {
    if (this.searchByProductName != null || this.searchByProductName == "") {
      this.filteredProducts = this.products.filter(prod => prod.ProductName.toLowerCase().indexOf(this.searchByProductName.toLowerCase()) >= 0);
    }
    else {
      this.filteredProducts = this.products;
    }
    this.searchByCategoryId = categoryId;
    if (this.searchByCategoryId == "0") {
      this.filteredProducts = this.products;
    }
    else {
      this.filteredProducts = this.filteredProducts.filter(prod => prod.CategoryId.toString() == this.searchByCategoryId);
    }
  }

  addToCart(prod: IProduct) {
    //debugger;
    this.userName = sessionStorage.getItem('userName');
    if (this.userRole == null) {
      this.router.navigate(['/login']);
    }
    else {
      this.userService.addProductToCart(prod.ProductId, this.userName)
        .subscribe(  
        responseProductData => {
          //debugger;
            //this.message = responseProductData;
            if (responseProductData) {
              alert("Product added sucessfully.")
            }
          },
          responseProductError => {
            this.errMsg = responseProductError,
              console.log(this.errMsg),
              alert("Sorry, something went wrong. Please try again after sometime.")
          },
          () => console.log("AddToCart method executed successfully")
        );
    }


  }
}



  //3. event binding

  //onClick() {
  //  //alert("button was clicked");
  //  console.log(this.name);
  //}



