import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.css']
})
export class UserregisterComponent implements OnInit {

  status: boolean;
  errorMsg: string;
  msg: string;
  showDiv: boolean = false;

  constructor(private userservice: UserService, private router: Router) { }

  ngOnInit() {
  }
  
  register(form: NgForm) {
    
    this.userservice.InsertUserDetails(form.value.email, form.value.password, form.value.gender, form.value.address).subscribe(
      response => {
        this.status = response;
        this.router.navigate[' '];
      },
      error => {
        console.log("error occured in register method user service");
        this.errorMsg = error;
      },
      () => { console.log("register method exceuted successfully"); }
    );
  }

}
